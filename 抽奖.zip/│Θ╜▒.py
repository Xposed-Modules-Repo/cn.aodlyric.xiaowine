from hashlib import md5
from random import randint

from openpyxl import load_workbook

file_name = r"C:\Users\xiaow\Downloads\查重后的提交表.xlsx"
wb = load_workbook(file_name)  # 读取xlsx

with open(file_name, 'rb') as fp:
    data = fp.read()
file_md5 = md5(data).hexdigest()
print("xlsxMD5值：", file_md5)  # ac3ee699961c58ef80a78c2434efe0d

sheet_names = wb.sheetnames
ws = wb["《墨•息》 购买 高级模式 提交（收集结果）"]  # 读取xlsx层
maxRows = ws.max_row  # 读取xlsx最大排数
for i in range(3):  # 循环3次
    value = randint(2, maxRows)  # 根据读取xlsx最大排数，生成随机数
    print("#" * 40)  # 打印分割线
    print("行数：", value)  # 打印随机数
    print("用户名：", ws.cell(value, 1).value)
    print("联系方式：", ws.cell(value, 11).value)
